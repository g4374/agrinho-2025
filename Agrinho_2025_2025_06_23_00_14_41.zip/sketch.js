let fase = "menu";
let sementes = {
  milho: 5,
  alface: 5,
  cenoura: 5,
  tomate: 5
};
let colheita = [];
let pontos = 0;
let plantas = [];
let tempoCrescimento = 300;
let caminhao;
let tipoPlantaAtual = "milho";
let botoes = {};
let tempo = 0;
let clima = "sol";

function setup() {
  createCanvas(windowWidth, windowHeight);
  caminhao = new Caminhao();
  criarBotoes();
}

function draw() {
  desenhaFundo();
  tempo++;
  if (tempo % 600 === 0) mudaClima();

  if (fase === "menu") {
    desenhaMenu();
    esconderTodosBotoes();
  } else if (fase === "campo") {
    desenhaCampo();
    mostrarBotoesCampo();
  } else if (fase === "cidade") {
    desenhaCidade();
    mostrarBotoesCidade();
  }

  desenhaHUD();
}

function desenhaFundo() {
  let t = millis() / 1000;
  let cor = map(sin(t), -1, 1, 100, 200);
  if (clima === "chuva") {
    background(100, 100, 120);
    for (let i = 0; i < width; i += 20) {
      stroke(200);
      line(i, random(height), i, random(height + 30));
    }
  } else if (clima === "nublado") {
    background(cor, cor, cor + 30);
    fill(240);
    ellipse(100, 80, 100, 60);
    ellipse(160, 80, 120, 70);
  } else {
    background(100, cor, 255);
    fill(255, 255, 0);
    ellipse(60, 60, 60);
  }
}

function desenhaMenu() {
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(32);
  text("🌾 Agrinho: Conexão Campo-Cidade 🌆", width / 2, height / 2 - 60);
  textSize(20);
  text("Clique para começar", width / 2, height / 2);
}

function desenhaCampo() {
  for (let p of plantas) {
    p.crescer();
    p.mostrar();
  }

  desenhaPersonagem(width - 100, height - 140);
}

function desenhaCidade() {
  caminhao.mover();
  caminhao.mostrar();
  desenhaPersonagem(width - 100, height - 140);
}

function desenhaHUD() {
  fill(255, 230);
  rect(0, height - 60, width, 60);
  fill(0);
  textSize(14);
  textAlign(LEFT);
  let colhidas = colheita.map(p => p.emoji).join(" ");
  text(`🌱 Sementes: ${JSON.stringify(sementes)} | 🌾 Colheita: ${colhidas} | 💰 Pontos: ${pontos} | ☀️ Clima: ${clima}`, 10, height - 40);
}

function mousePressed() {
  if (fase === "menu") {
    fase = "campo";
    return;
  }

  // Planting logic
  if (fase === "campo" && sementes[tipoPlantaAtual] > 0 && mouseY > 100) {
    let plantOverlap = false;
    for (let p of plantas) {
      // Check if clicking on an empty spot (not on an existing plant or too close)
      let plantingRadius = 25; // A reasonable radius for planting
      if (dist(mouseX, mouseY, p.x, p.y) < plantingRadius && !p.colhida) {
        plantOverlap = true;
        break;
      }
    }
    if (!plantOverlap) {
      plantas.push(new Planta(mouseX, mouseY, tipoPlantaAtual));
      sementes[tipoPlantaAtual]--;
    }
  }
}

function mouseClicked() {
  // Harvesting logic
  if (fase === "campo") {
    for (let i = plantas.length - 1; i >= 0; i--) {
      let p = plantas[i];
      // Check if clicking on a fully grown and unharvested plant
      let plantVisualHeight = min(p.crescimento, tempoCrescimento) / 10; // Use capped visual height for click
      let plantTopY = p.y - plantVisualHeight;
      let harvestRadius = 25; // A more generous radius for clicking
      if (
        dist(mouseX, mouseY, p.x, plantTopY) < harvestRadius &&
        p.crescimento >= tempoCrescimento &&
        !p.colhida
      ) {
        p.colhida = true;
        colheita.push(p);
        // Optional: uncomment the line below to remove the plant from the field visually after harvesting
        // plantas.splice(i, 1);
        break; // Only harvest one plant per click
      }
    }
  }
}


function criarBotoes() {
  botoes.transportar = createButton('🚚 Transportar');
  botoes.transportar.position(10, 60);
  botoes.transportar.mousePressed(() => {
    if (fase === "campo" && colheita.length > 0) {
      fase = "cidade";
      caminhao.iniciarViagem(colheita.length);
      colheita = [];
    }
  });

  botoes.vender = createButton('💰 Vender');
  botoes.vender.position(150, 60);
  botoes.vender.mousePressed(() => {
    if (fase === "cidade" && !caminhao.movendo) {
      pontos += caminhao.carregando;
      for (let tipo in sementes) sementes[tipo] += 1;
      caminhao.carregando = 0;
      fase = "campo";
    }
  });

  const tipos = ["milho", "alface", "cenoura", "tomate"];
  tipos.forEach((tipo, i) => {
    botoes[tipo] = createButton(emojiPlanta(tipo) + " " + tipo);
    botoes[tipo].position(300 + i * 80, 60);
    botoes[tipo].mousePressed(() => tipoPlantaAtual = tipo);
  });

  esconderTodosBotoes();
}

function esconderTodosBotoes() {
  for (let chave in botoes) botoes[chave].hide();
}

function mostrarBotoesCampo() {
  botoes.transportar.show();
  for (let tipo of ["milho", "alface", "cenoura", "tomate"]) {
    botoes[tipo].show();
  }
  botoes.vender.hide();
}

function mostrarBotoesCidade() {
  botoes.vender.show();
  botoes.transportar.hide();
  for (let tipo of ["milho", "alface", "cenoura", "tomate"]) {
    botoes[tipo].hide();
  }
}

function mudaClima() {
  let opcoes = ["sol", "nublado", "chuva"];
  clima = random(opcoes);
}

class Planta {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.crescimento = 0;
    this.colhida = false;
    this.emoji = emojiPlanta(tipo);
  }

  crescer() {
    if (this.colhida) return;

    let fator = 1;
    if (clima === "sol") fator = 1;
    else if (clima === "nublado") fator = 0.7;
    else if (clima === "chuva") fator = 1.5;

    // The internal growth continues, but it will be capped visually
    this.crescimento += fator;
  }

  mostrar() {
    if (!this.colhida) {
      fill(0);
      textSize(20);
      // Calculate display height, but cap it at the fully grown state
      let visualGrowth = min(this.crescimento, tempoCrescimento);
      let displayY = this.y - visualGrowth / 10; // Divide by 10 to control the visual "lift"

      text(this.emoji, this.x, displayY);
    }
  }
}

function emojiPlanta(tipo) {
  switch (tipo) {
    case "milho":
      return "🌽";
    case "alface":
      return "🥬";
    case "cenoura":
      return "🥕";
    case "tomate":
      return "🍅";
    default:
      return "🌱";
  }
}

class Caminhao {
  constructor() {
    this.x = 0;
    this.y = height / 2;
    this.carregando = 0;
    this.movendo = false;
  }

  iniciarViagem(qtd) {
    this.carregando = qtd;
    this.x = 0;
    this.movendo = true;
  }

  mover() {
    if (this.movendo) {
      this.x += 2;
      if (this.x > width - 60) {
        this.movendo = false;
      }
    }
  }

  mostrar() {
    fill(200, 0, 0);
    rect(this.x, this.y - 20, 60, 30);
    fill(0);
    ellipse(this.x + 10, this.y + 15, 15, 15);
    ellipse(this.x + 50, this.y + 15, 15, 15);
  }
}

function desenhaPersonagem(x, y) {
  push();
  translate(x, y);
  fill(255, 200, 150);
  ellipse(20, 20, 30, 30); // Cabeça
  fill(100, 200, 255);
  rect(5, 35, 30, 40); // Corpo
  fill(150, 75, 0);
  rect(5, 75, 10, 20); // Perna esquerda
  rect(25, 75, 10, 20); // Perna direita
  fill(255, 200, 150);
  ellipse(0, 50, 10, 10); // Braço esquerdo
  ellipse(40, 50, 10, 10); // Braço direito
  pop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}